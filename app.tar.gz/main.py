#!/usr/bin/python3 

""" 
Fórmula para cálculo da concentração da vancomicina em μg/mL por hora                                                   
Coletado na 4ª dose na função renal normal
- Necessário a dose de aplicação: dose
- Intervalo entre doses: Tau
- Duração de infusão: Tinf
- Dose de pico (uma hora após a infusão)
- Tempo do início da infusão para o pico: T1
- Dose de vale (30 minutos antes da próxima dose)
- Tempo do início da infusão ao vale: T2
   
O cálculo de ajuste pode ser realizado com alteração da dose diária, pois será proporcional.
"""

import flet as ft
import math

def auc(pico,vale,T1,T2,Tinf,Tau):

	""" Caulculo da área sob a curva """
	
	# cálculo da constante de eliminação
	Ke = math.log(pico/vale) / (T2-T1)
	# cálculo do pico verdadeiro
	True_peak = pico / (math.e**(-Ke*(T1-Tinf)))
	# cálculo do vale verdadeiro
	True_trough = vale * (math.e**(-Ke*(Tau-T2)))
	# cálculo da curva de infusão
	AUCinf = ((True_trough + True_peak)/2)*Tinf
	# cálculo da curva de eliminação
	AUCelim = (True_peak - True_trough)/Ke
	# cálculo da área sob a curva
	AUC24 = (AUCinf + AUCelim)*(24/Tau)
	
	return Ke,True_peak,True_trough,AUCinf,AUCelim,AUC24

def previstos(ndose,nTinf,nTau,dose,pico,vale,T1,T2,Tinf,Tau):

	""" Cálculos do novo pico e vale """
	
	# cálculos iniciais da constante e pico e vale verdadeiros
	r = auc(pico,vale,T1,T2,Tinf,Tau)
	# valor de distribuição
	Vd = (dose*(1 - (math.e**(-r[0]*Tinf)))) / (Tinf*r[0]*(r[1] - (r[2] * math.e**(-r[0]*Tinf))))
	# depuração de creatitina - "clearance"
	depurado = Vd * r[0]
	# novo pico
	npico = (ndose / depurado * nTinf) * ((1 - (math.e**(-r[0]*nTinf))) / (1 - (math.e**(-r[0]*nTau))))
	# novo vale
	nvale = npico * (math.e**(-r[0]*(nTau - nTinf)))

	return npico,nvale,Vd,depurado

def corrigido(ndose,nTinf,nTau,nT1,nT2,dose,pico,vale,T1,T2,Tinf,Tau):
	
	""" Cálculo da nova curva após correção de dose """

	# Cálculos preditos para vales e picos com novas doses
	predito = previstos(ndose,nTinf,nTau,dose,pico,vale,T1,T2,Tinf,Tau)
	# nova curva sob a área com as doses corrigidas
	nova_auc = auc(predito[0],predito[1],nT1,nT2,nTinf,nTau)

	return nova_auc

def main(page: ft.Page):

	""" Aplicativo para cálculo da vancomicina """

	page.title = "Vancometria© 2023 Luiz Guilherme Gonçalves"
	page.vertical_alignment = ft.MainAxisAlignment.CENTER
	page.scroll=True

	ndose = ft.TextField(label="Nova dose",text_align=ft.TextAlign.RIGHT, width=300)
	nTinf = ft.TextField(label="Novo tempo de infusão",text_align=ft.TextAlign.RIGHT, width=300)
	nTau = ft.TextField(label="Novo intervalo entre doses",text_align=ft.TextAlign.RIGHT, width=300)
	nT1 = ft.TextField(label="Novo tempo até coleta de pico",text_align=ft.TextAlign.RIGHT, width=300)
	nT2 = ft.TextField(label="Novo tempo até coleta de vale",text_align=ft.TextAlign.RIGHT, width=300)
	dose = ft.TextField(label="Dose atual",text_align=ft.TextAlign.RIGHT, width=300)
	pico = ft.TextField(label="Pico aferido",text_align=ft.TextAlign.RIGHT, width=300)
	vale = ft.TextField(label="Vale aferido",text_align=ft.TextAlign.RIGHT, width=300)
	T1 = ft.TextField(label="Tempo até coleta de pico",text_align=ft.TextAlign.RIGHT, width=300)
	T2 = ft.TextField(label="Tempo até coleta de vale",text_align=ft.TextAlign.RIGHT, width=300)
	Tinf = ft.TextField(label="Tempo de infusão",text_align=ft.TextAlign.RIGHT, width=300)
	Tau = ft.TextField(label="Intervalo entre doses",text_align=ft.TextAlign.RIGHT, width=300)

	def area_sob_curva(e):
		a,b,c,d,e,f = float(pico.value),float(vale.value),float(T1.value),float(T2.value),float(Tinf.value),float(Tau.value)
		c = auc(a,b,c,d,e,f)
		r.value = round(c[5])
		if r.value >= 400 and r.value <= 600:
			r.color = ft.colors.GREEN_400
		else:
			r.color = ft.colors.RED_400
		
		page.update()

	def ajuste(e):
		a,b,c,d,e,f,g,h,i,j,k,l = float(ndose.value),float(nTinf.value),float(nTau.value),float(nT1.value),float(nT2.value),float(dose.value),float(pico.value),float(vale.value),float(T1.value),float(T2.value),float(Tinf.value),float(Tau.value)
		p = previstos(a,b,c,f,g,h,i,j,k,l)
		c = auc(p[0],p[1],d,e,b,c)
		r.value = round(c[5])
		if r.value >= 400 and r.value <= 600:
			r.color = ft.colors.GREEN_400
		else:
			r.color = ft.colors.RED_400

		page.update()

	r = ft.Text(size=30, value="000")

	submeter_auc = ft.ElevatedButton("AUC", height=60, on_click=area_sob_curva)
	submeter_ajuste = ft.ElevatedButton("Ajuste", height=60, on_click=ajuste)
	legenda = ft.Text(size=20,value="Resultado: ")
	unidade = ft.Text(size=20,value="mg.hr.L⁻¹")
	cabeçalho = ft.Text(size=40,value="VANCOMETRIA©")
	

	page.add(
		ft.Row([cabeçalho],alignment=ft.MainAxisAlignment.CENTER),
		ft.Row([ndose],alignment=ft.MainAxisAlignment.CENTER),
		ft.Row([nTinf],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([nTau],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([nT1],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([nT2],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([dose],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([pico],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([vale],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([T1],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([T2],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([Tinf],alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([Tau],alignment=ft.MainAxisAlignment.CENTER),
		ft.Row([submeter_auc,submeter_ajuste],alignment=ft.MainAxisAlignment.CENTER),
		ft.Row([legenda,r,unidade],alignment=ft.MainAxisAlignment.CENTER),
		)

ft.app(target=main, view=ft.AppView.WEB_BROWSER)
